const adminPermissions = [
  "Home",
  "Place On-Demand Order",
  "Track Orders",
  "Track Schedule Orders",
  "Assign Drivers",

  "Customers",
  "Address Points",
  "Account Managers",
  "Drivers",

  "Dispatch",

  "Roles",
  "Users",
  "Default Prices",
];

const companyPermissions = [
  "Home",
  "Place On-Demand Order",
  "Track Orders",
  "Track Schedule Orders",

  "Address Points",

  "Dispatch",

  "Roles",
  "Users",
];
