import { Component } from '@angular/core';

@Component({
  selector: 'app-schedule-orders',
  templateUrl: './schedule-orders.component.html',
  styleUrls: ['./schedule-orders.component.scss']
})
export class ScheduleOrdersComponent {

}
