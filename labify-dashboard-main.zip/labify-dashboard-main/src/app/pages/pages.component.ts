import { Component } from '@angular/core';
import { FirebaseCloudMessagingService } from '../core/services/firebase-cloud-messaging.service';

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss'],
})
export class PagesComponent {}
