import { Component } from '@angular/core';

@Component({
  selector: 'app-system-setup',
  templateUrl: './system-setup.component.html',
  styleUrls: ['./system-setup.component.scss']
})
export class SystemSetupComponent {

}
