import { Component } from "@angular/core";

@Component({
  selector: "ngx-company-address",
  templateUrl: "./company-address.component.html",
  styleUrls: ["./company-address.component.scss"],
})
export class CompanyAddressComponent {}
