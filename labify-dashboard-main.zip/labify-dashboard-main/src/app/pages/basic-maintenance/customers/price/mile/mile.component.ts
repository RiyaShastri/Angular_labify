import { Component } from '@angular/core';

@Component({
  selector: 'app-mile',
  templateUrl: './mile.component.html',
  styleUrls: ['./mile.component.scss']
})
export class MileComponent {

}
