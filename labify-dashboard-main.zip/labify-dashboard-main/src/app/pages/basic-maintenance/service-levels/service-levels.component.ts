import { Component } from '@angular/core';

@Component({
  selector: 'app-service-levels',
  templateUrl: './service-levels.component.html',
  styleUrls: ['./service-levels.component.scss']
})
export class ServiceLevelsComponent {

}
