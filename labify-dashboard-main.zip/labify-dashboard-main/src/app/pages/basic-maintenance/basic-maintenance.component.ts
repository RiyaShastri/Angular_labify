import { Component } from '@angular/core';

@Component({
  selector: 'app-basic-maintenance',
  templateUrl: './basic-maintenance.component.html',
  styleUrls: ['./basic-maintenance.component.scss']
})
export class BasicMaintenanceComponent {

}
