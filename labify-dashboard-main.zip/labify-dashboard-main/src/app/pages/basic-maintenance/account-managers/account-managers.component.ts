import { Component } from '@angular/core';

@Component({
  selector: 'app-account-managers',
  templateUrl: './account-managers.component.html',
  styleUrls: ['./account-managers.component.scss']
})
export class AccountManagersComponent {

}
