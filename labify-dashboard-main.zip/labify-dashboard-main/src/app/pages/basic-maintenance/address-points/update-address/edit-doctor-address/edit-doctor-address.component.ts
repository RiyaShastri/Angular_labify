import { Component } from "@angular/core";

@Component({
  selector: "ngx-edit-doctor-address",
  templateUrl: "./edit-doctor-address.component.html",
  styleUrls: ["./edit-doctor-address.component.scss"],
})
export class EditDoctorAddressComponent {}
