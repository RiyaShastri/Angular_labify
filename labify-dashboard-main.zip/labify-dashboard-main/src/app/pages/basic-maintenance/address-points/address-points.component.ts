import { Component } from '@angular/core';

@Component({
  selector: 'app-address-points',
  templateUrl: './address-points.component.html',
  styleUrls: ['./address-points.component.scss']
})
export class AddressPointsComponent {

}
