import { Component } from '@angular/core';

@Component({
  selector: 'app-update-cancel-orders',
  templateUrl: './update-cancel-orders.component.html',
  styleUrls: ['./update-cancel-orders.component.scss']
})
export class UpdateCancelOrdersComponent {

}
