import { Component } from '@angular/core';

@Component({
  selector: 'app-mark-orders-recieved',
  templateUrl: './mark-orders-recieved.component.html',
  styleUrls: ['./mark-orders-recieved.component.scss']
})
export class MarkOrdersRecievedComponent {

}
