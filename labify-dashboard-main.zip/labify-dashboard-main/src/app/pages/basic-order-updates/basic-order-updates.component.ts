import { Component } from '@angular/core';

@Component({
  selector: 'app-basic-order-updates',
  templateUrl: './basic-order-updates.component.html',
  styleUrls: ['./basic-order-updates.component.scss']
})
export class BasicOrderUpdatesComponent {

}
