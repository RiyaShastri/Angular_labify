import { Component } from '@angular/core';

@Component({
  selector: 'app-note-pad-codes',
  templateUrl: './note-pad-codes.component.html',
  styleUrls: ['./note-pad-codes.component.scss']
})
export class NotePadCodesComponent {

}
