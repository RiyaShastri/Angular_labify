export type Company ={
  id:number;
  first_name:string;
  last_name:string;
  username:string;
  phone:string;
  email:string;
  image?:string;

}
