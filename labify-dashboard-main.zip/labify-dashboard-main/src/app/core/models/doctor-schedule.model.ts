export type DoctorSchedule = {
  id: number;
  day: string;
  from: string;
  to: string;
  address: number;
};
