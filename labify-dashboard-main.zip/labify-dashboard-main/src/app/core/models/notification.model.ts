export type NotificationData = {
  id: number;
  title: string;
  message: string;
  created_at: Date;
};
