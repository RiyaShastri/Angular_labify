export type CompanyName = {
  name: any;
  id: number;
};
