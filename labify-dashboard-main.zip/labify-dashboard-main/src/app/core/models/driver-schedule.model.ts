export type DriverSchedule = {
  from: string;
  to: string;
  day: string;
};
