export type City = {
  id: number;
  city: string;
  postal_code: string;
};
