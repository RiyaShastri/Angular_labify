import { Component } from '@angular/core';

@Component({
  selector: 'app-map-svg',
  templateUrl: './map-svg.component.html',
  styleUrls: ['./map-svg.component.scss']
})
export class MapSvgComponent {

}
