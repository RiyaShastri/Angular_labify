export type AddressParams = {
  address_id: number;
  district_id: number;
  address: string;
  postal_code: number;
};
