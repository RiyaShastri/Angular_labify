export type GrandTotal = {
  subtotal: number;
  user_id: number;
  order_status_id: number;
  total_quantity: number;
  coupon_id: number;
  coupon_price: number;
  grand_total: number;
  shipping_price: number;
};
