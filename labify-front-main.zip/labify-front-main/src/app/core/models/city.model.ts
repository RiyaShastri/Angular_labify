export type City = {
  id: number;
  name: string;
};
