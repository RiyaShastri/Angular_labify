export const environment = {
  production: false,
  apiUrl: 'https://website.labyfi.com/api/web',
};
