export const environment = {
  production: true,
  apiUrl: 'https://website.labyfi.com/api/web',
};
